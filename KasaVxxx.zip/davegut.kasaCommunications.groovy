import groovy.json.JsonSlurper
library (
	name: "kasaCommunications",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Kasa Communications Methods",
	category: "communications",
	documentationLink: ""
)
////////////////////////////////////////////////////
def sendCmd(command) {
	if (device.currentValue("connection") == "LAN") {
		sendLanCmd(command)
	} else if (device.currentValue("connection") == "CLOUD"){
		sendKasaCmd(command)
	} else if (device.currentValue("connection") == "AltLAN") {
		sendTcpCmd(command)
	} else {
		logWarn("sendCmd: attribute connection not set.")
	}
}
////////////////////////////////////////////////////////
def sendLanCmd(command) {
	logDebug("sendLanCmd: command = ${command}")
	if (!command.contains("password")) {
		state.lastCommand = command
	}
	def myHubAction = new hubitat.device.HubAction(
		outputXOR(command),
		hubitat.device.Protocol.LAN,
		[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
		 destinationAddress: "${getDataValue("deviceIP")}:9999",
		 encoding: hubitat.device.HubAction.Encoding.HEX_STRING,
		 parseWarning: true,
//////////////////////////////////////////////////////////////////////
		 timeout: 10,
		 callback: parseUdp])
	try {
		sendHubCommand(myHubAction)
	} catch (e) {
		logWarn("sendLanCmd: LAN Error = ${e}")
		handleCommsError()
	}
}

def parseUdp(message) {
	def resp = parseLanMessage(message)
	if (resp.type == "LAN_TYPE_UDPCLIENT") {
		def clearResp = inputXOR(resp.payload)
		if (clearResp.length() > 1022) {
			clearResp = clearResp.substring(0,clearResp.indexOf("preferred")-2) + "}}}"
		}
		def cmdResp = new JsonSlurper().parseText(clearResp)
		distResp(cmdResp)
	} else {
		logDebug("parse: LAN Error = ${resp.type}")
		handleCommsError()
	}
}

def sendKasaCmd(command) {
	logDebug("sendKasaCmd: ${command}")
	state.lastCommand = command
	runIn(5, handleCommsError)
	def cmdResponse = ""
	def cmdBody = [
		method: "passthrough",
		params: [
			deviceId: getDataValue("deviceId"),
			requestData: "${command}"
		]
	]
	def sendCloudCmdParams = [
		uri: "${parent.kasaCloudUrl}/?token=${parent.kasaToken}",
		requestContentType: 'application/json',
		contentType: 'application/json',
		headers: ['Accept':'application/json; version=1, */*; q=0.01'],
		timeout: 5,
		body : new groovy.json.JsonBuilder(cmdBody).toString()
	]
	try {
		httpPostJson(sendCloudCmdParams) {resp ->
			if (resp.status == 200 && resp.data.error_code == 0) {
				def jsonSlurper = new groovy.json.JsonSlurper()
				distResp(jsonSlurper.parseText(resp.data.result.responseData))
			} else {
				def errMsg = "CLOUD Error = ${resp.data}"
				logWarn("sendKasaCmd: ${errMsg}]")
			}
		}
	} catch (e) {
		def errMsg = "CLOUD Error = ${e}"
		logWarn("sendKasaCmd: ${errMsg}]")
	}
}

/////////////////////////////////////////////////////////////////
private sendTcpCmd(command) {
	logDebug("sendTcpCmd: ${command}")
	try {
		interfaces.rawSocket.connect("${getDataValue("deviceIP")}", 
									 9999, byteInterface: true)
	} catch (error) {
		logDebug("SendTcpCmd: Unable to connect to device at ${getDataValue("deviceIP")}. " +
				 "Error = ${error}")
	}
	runIn(5, handleCommsError)
	state.lastCommand = command
	interfaces.rawSocket.sendMessage(outputXorTcp(command))
}
////////////////////////////////////////////////////////////////////////////////
def socketStatus(message) {
	if (message == "receive error: Stream closed.") {
		logDebug("socketStatus: Socket Established")
	} else {
		logWarn("socketStatus = ${message}")
	}
}
////////////////////////////////////////////////////
def parse(message) {
	def respLength
	if (message.length() > 8 && message.substring(0,4) == "0000") {
		def hexBytes = message.substring(0,8)
		respLength = 8 + 2 * hubitat.helper.HexUtils.hexStringToInt(hexBytes)
		if (message.length() == respLength) {
			extractResp(message)
		} else {
			state.response = message
			state.respLength = respLength
		}
	} else if (message.length() == 0 || message == null) {
		return
	} else {
		def resp = state.response
		resp = resp.concat(message)
		if (resp.length() == state.respLength) {
			state.response = ""
			state.respLength = 0
			extractResp(message)
		} else {
			state.response = resp
		}
	}
}
/////////////////////////////////////////////////
def extractResp(message) {
	if (message.length() == null) {
		logDebug("extractResp: null return rejected.")
		return 
	}
	logDebug("extractResp: ${message}")
	try {
		distResp(parseJson(inputXorTcp(message)))
	} catch (e) {
		logWarn("extractResp: Invalid or incomplete return.\nerror = ${e}")
		handleCommsError()
	}
}

def handleCommsError() {
	def count = state.errorCount + 1
	state.errorCount = count
	def message = "handleCommsError: Count: ${count}."
	if (count <= 3) {
		message += "\n\t\t\t Retransmitting command, try = ${count}"
		runIn(1, sendCmd, [data: state.lastCommand])
	} else if (count == 4) {
		setCommsError()
		message += "\n\t\t\t Setting Comms Error."
	}
	logDebug(message)
}

def setCommsError() {
	def message = "setCommsError: Four consecutive errors.  Setting commsError to true."
	if (device.currentValue("commsError") == "false") {
		sendEvent(name: "commsError", value: "true")
//	handle AltLAN connection
		message += "\n\t\tFix attempt ${parent.fixConnection(device.currentValue("connection"))}"
		logWarn message
	}
}

def resetCommsError() {
	unschedule(handleCommsError)
	sendEvent(name: "commsError", value: "false")
	state.errorCount = 0
}

private outputXOR(command) {
	def str = ""
	def encrCmd = ""
 	def key = 0xAB
	for (int i = 0; i < command.length(); i++) {
		str = (command.charAt(i) as byte) ^ key
		key = str
		encrCmd += Integer.toHexString(str)
	}
   	return encrCmd
}

private inputXOR(encrResponse) {
	String[] strBytes = encrResponse.split("(?<=\\G.{2})")
	def cmdResponse = ""
	def key = 0xAB
	def nextKey
	byte[] XORtemp
	for(int i = 0; i < strBytes.length; i++) {
		nextKey = (byte)Integer.parseInt(strBytes[i], 16)	// could be negative
		XORtemp = nextKey ^ key
		key = nextKey
		cmdResponse += new String(XORtemp)
	}
	return cmdResponse
}

////////////////////////////////////////////////////////////
private outputXorTcp(command) {
	def str = ""
	def encrCmd = "000000" + Integer.toHexString(command.length()) 
 	def key = 0xAB
	for (int i = 0; i < command.length(); i++) {
		str = (command.charAt(i) as byte) ^ key
		key = str
		encrCmd += Integer.toHexString(str)
	}
   	return encrCmd
}
//////////////////////////////////
private inputXorTcp(resp) {
	String[] strBytes = resp.substring(8).split("(?<=\\G.{2})")
	def cmdResponse = ""
	def key = 0xAB
	def nextKey
	byte[] XORtemp
	for(int i = 0; i < strBytes.length; i++) {
		nextKey = (byte)Integer.parseInt(strBytes[i], 16)	// could be negative
		XORtemp = nextKey ^ key
		key = nextKey
		cmdResponse += new String(XORtemp)
	}
	return cmdResponse
}

def logTrace(msg){
	log.trace "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
}

def logInfo(msg) {
	if (descriptionText == true) { 
		log.info "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
	}
}

def logDebug(msg){
	if(debug == true) {
		log.debug "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
	}
}

def debugOff() {
	device.updateSetting("debug", [type:"bool", value: false])
	logInfo("debugLogOff: Debug logging is off.")
}

def logWarn(msg){
	log.warn "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
}

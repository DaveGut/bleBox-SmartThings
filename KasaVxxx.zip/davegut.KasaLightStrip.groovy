/*	Kasa Device Driver Series

		Copyright Dave Gutheinz

License Information:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

===== Version 6.4.2 =====
1.  Tweaked communications protocol to reduce errors.
====================================
6.4.2.1 - Added preference Sync Name
===================================================================================================*/
def driverVer() { return "6.4.2.1" }
def type() { return "Light Strip" }

metadata {
	definition (name: "Kasa Light Strip",
				namespace: "davegut",
				author: "Dave Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/KasaDevices/DeviceDrivers/LightStrip.groovy"
			   ) {
        capability "Light"
		capability "Switch"
		capability "Switch Level"
		capability "Change Level"
 		capability "Refresh"
		capability "Actuator"
		capability "Color Temperature"
		capability "Color Mode"
		capability "Color Control"
		capability "Light Effects"
		command "effectSet", [[
			name: "Name for effect.", 
			type: "STRING"]]
		command "effectCreate"
		command "effectDelete", [[
			name: "Name for effect to delete.", 
			type: "STRING"]]
		//	Poll Interval Function
		command "setPollInterval", [[
			name: "Poll Interval in seconds",
			constraints: ["default", "5 seconds", "10 seconds", "15 seconds",
						  "30 seconds", "1 minute", "5 minutes",  "10 minutes",
						  "30 minutes"],
			type: "ENUM"]]
		//	Energy Monitor
		capability "Power Meter"
		capability "Energy Meter"
		//	Psuedo Capability Energy Statistics
		attribute "currMonthTotal", "number"
		attribute "currMonthAvg", "number"
		attribute "lastMonthTotal", "number"
		attribute "lastMonthAvg", "number"
		//	SCommunications Attributes
		attribute "connection", "string"
		attribute "commsError", "string"
		//	Psuedo capability Light Presets
		command "bulbPresetCreate", [[
			name: "Name for preset.", 
			type: "STRING"]]
		command "bulbPresetDelete", [[
			name: "Name for preset.", 
			type: "STRING"]]
		command "bulbPresetSet", [[
			name: "Name for preset.", 
			type: "STRING"],[
			name: "Transition Time (seconds).", 
			type: "STRING"]]
		attribute "bulbPreset", "string"
		command "setRGB", [[
			name: "red,green,blue", 
			type: "STRING"]]
	}

	preferences {
		input ("emFunction", "bool", 
				   title: "Enable Energy Monitor", 
				   defaultValue: false)
		input ("transition_Time", "num",
			   title: "Default Transition time in sec.",
			   defaultValue: 0)
		input ("syncEffects", "bool",
			   title: "Sync Effect Preset Data",
			   defaultValue: false)
		input ("syncBulbs", "bool",
			   title: "Sync Bulb Preset Data",
			   defaultValue: false)
		input ("debug", "bool",
			   title: "Debug logging, 30 min.", 
			   defaultValue: false)
		input ("descriptionText", "bool", 
			   title: "Description Text Logging", 
			   defaultValue: true)
		input ("nameSync", "enum", title: "Synchronize Names",
			   defaultValue: "none",
			   options: ["none": "Don't synchronize",
						 "device" : "Kasa device name master", 
						 "Hubitat" : "Hubitat label master"])
		input ("bind", "bool",
			   title: "Kasa Cloud Binding",
			   defaultValue: true)
		if (bind && parent.useKasaCloud) {
			input ("useCloud", "bool",
				   title: "Kasa Cloud Device Control",
				   defaultValue: false)
		}
		input ("rebootDev", "bool",
			   title: "Reboot Device",
			   defaultValue: false)
	}
}

def installed() {
	logInfo("Installing Device...")
	state.errorCount = 0
	if (parent.useKasaCloud) {
		logInfo("install: Installing as CLOUD device.")
		device.updateSetting("useCloud", [type:"bool", value: true])
		sendEvent(name: "connection", value: "CLOUD")
	} else {
		logInfo("install: Installing as LAN device")
		sendEvent(name: "connection", value: "LAN")
		device.updateSetting("useCloud", [type:"bool", value: false])
	}
	state.pollInterval = "30 minutes"
	updateDataValue("driverVersion", driverVer())
	state.effectPresets = []
	state.bulbPresets = [:]
	sendEvent(name: "lightEffects", value: [])
	runIn(3, updated)
}

def updated() {
	if (rebootDev) {
		logWarn("updated: ${rebootDevice()}")
	}
	if (syncEffects) {
		logDebug("updated: ${syncEffectPresets()}")
		return
	}
	if (syncBulbs) {
		logDebug("updated: ${syncBulbPresets()}")
		return
	}
	unschedule()
	def updStatus = [:]
	if (debug) { runIn(1800, debugOff) }
	updStatus << [debug: debug]
	updStatus << [descriptionText: descriptionText]
	updStatus << [transition_Time: "${transition_Time} seconds"]
	state.errorCount = 0
	sendEvent(name: "commsError", value: "false")
	if (nameSync != "none") {
		updStatus << [nameSync: syncName()]
	}
	updStatus << [bind: bindUnbind()]
	updStatus << [emFunction: setupEmFunction()]
	updStatus << [pollInterval: setPollInterval()]
	updStatus << [driverVersion: updateDriverData()]
	log.info "[${type()}, ${driverVer()}, ${device.label}]  updated: ${updStatus}"
	runIn(3, refresh)
}

def updateDriverData() {
	if (drvVer == !driverVer()) {
		state.remove("lastLanCmd")
		state.remove("commsErrorText")
		if (!state.bulbPresets) { state.bulbPresets = [:] }
		if (!state.bulbPresets) { state.bulbPresets = [:] }
		updateDataValue("driverVersion", driverVer())
	}
	return driverVer()
}

def on() {
	logDebug("on: transition time = ${transition_Time}")
	if (transTime == null) { transTime = 0 }
	def transTime = 1000 * transition_Time.toInteger()
	sendCmd("""{"smartlife.iot.lightStrip":""" +
			"""{"set_light_state":{"on_off":1,"transition_period":${transTime}}},""" +
			""""smartlife.iot.common.emeter":{"get_realtime":{}}}""")
}

def off() {
	logDebug("off: transition time = ${transition_Time}")
	if (transTime == null) { transTime = 0 }
	def transTime = 1000 * transition_Time.toInteger()
	sendCmd("""{"smartlife.iot.lightStrip":""" +
			"""{"set_light_state":{"on_off":0,"transition_period":${transTime}}},""" +
			""""smartlife.iot.common.emeter":{"get_realtime":{}}}""")
}

def setLevel(level, transTime = transition_Time.toInteger()) {
	if (level < 0) { level = 0 }
	else if (level > 100) { level = 100 }
	logDebug("setLevel: ${level} // ${transTime}")
	if (transTime == null) { transTime = 0 }
	transTime = 1000*transTime
	sendCmd("""{"smartlife.iot.lightStrip":{"set_light_state":{"ignore_default":1,"on_off":1,""" +
			""""brightness":${level},"transition_period":${transTime}}},""" +
			""""smartlife.iot.common.emeter":{"get_realtime":{}}}""")
}

def setColorTemperature(colorTemp, level = device.currentValue("level"), transTime = transition_Time.toInteger()) {
	logDebug("setColorTemperature: ${colorTemp} // ${level} // ${transTime}")
	if (transTime == null) { transTime = 0 }
	transTime = 1000 * transTime
	if (colorTemp < 1000) { colorTemp = 1000 }
	else if (colorTemp > 12000) { colorTemp = 12000 }
	def hsvData = getCtHslValue(colorTemp)
	state.currentCT = colorTemp
	sendCmd("""{"smartlife.iot.lightStrip":{"set_light_state":{"ignore_default":1,""" +
			""""on_off":1,"brightness":${level},"color_temp":0,"hue":${hsvData.hue},""" +
			""""saturation":${hsvData.saturation},"transition_period":${transTime}}},""" +
			""""smartlife.iot.common.emeter":{"get_realtime":{}}}""")
}

def xxxxxgetCtHslValue(kelvin) {
	def temp = kelvin/100
	def red
	def green
	def blue
	if( temp <= 66 ){ 
        red = 255
 		green = temp
		green = 99.4708025861 * Math.log(green) - 161.1195681661;
		if( temp <= 19){
			blue = 0
		} else {
			blue = temp-10;
			blue = 138.5177312231 * Math.log(blue) - 305.0447927307
		}
	} else {
		red = temp - 60
		red = 329.698727446 * Math.pow(red, -0.1332047592)
		green = temp - 60
		green = 288.1221695283 * Math.pow(green, -0.0755148492 )
		blue = 255
	}
	red = limitValue(red)
	green = limitValue(green)
	blue = limitValue(blue)
	
	def hsvData = hubitat.helper.ColorUtils.rgbToHSV([red, green, blue])
	def hue = (0.5 + hsvData[0]).toInteger()
	def saturation = (0.5 + hsvData[1]).toInteger()
	def level = (0.5 + hsvData[2]).toInteger()
	def hslData = [
		hue: hue,
		saturation: saturation,
		level: level
		]
	return hslData
}

def xxxxxlimitValue(value) {
	value = value + 0.5
	if (value > 255) { value = 255 }
	else if (value < 0) { value = 0 }
	return value.toInteger()
}

def getCtHslValue(kelvin) {
	kelvin = 100 * Math.round(kelvin / 100)
	switch(kelvin) {
		case 1000: rgb= [255, 56, 0]; break
		case 1100: rgb= [255, 71, 0]; break
		case 1200: rgb= [255, 83, 0]; break
		case 1300: rgb= [255, 93, 0]; break
		case 1400: rgb= [255, 101, 0]; break
		case 1500: rgb= [255, 109, 0]; break
		case 1600: rgb= [255, 115, 0]; break
		case 1700: rgb= [255, 121, 0]; break
		case 1800: rgb= [255, 126, 0]; break
		case 1900: rgb= [255, 131, 0]; break
		case 2000: rgb= [255, 138, 18]; break
		case 2100: rgb= [255, 142, 33]; break
		case 2200: rgb= [255, 147, 44]; break
		case 2300: rgb= [255, 152, 54]; break
		case 2400: rgb= [255, 157, 63]; break
		case 2500: rgb= [255, 161, 72]; break
		case 2600: rgb= [255, 165, 79]; break
		case 2700: rgb= [255, 169, 87]; break
		case 2800: rgb= [255, 173, 94]; break
		case 2900: rgb= [255, 177, 101]; break
		case 3000: rgb= [255, 180, 107]; break
		case 3100: rgb= [255, 184, 114]; break
		case 3200: rgb= [255, 187, 120]; break
		case 3300: rgb= [255, 190, 126]; break
		case 3400: rgb= [255, 193, 132]; break
		case 3500: rgb= [255, 196, 137]; break
		case 3600: rgb= [255, 199, 143]; break
		case 3700: rgb= [255, 201, 148]; break
		case 3800: rgb= [255, 204, 153]; break
		case 3900: rgb= [255, 206, 159]; break
		case 4000: rgb= [100, 209, 200]; break
		case 4100: rgb= [255, 211, 168]; break
		case 4200: rgb= [255, 213, 173]; break
		case 4300: rgb= [255, 215, 177]; break
		case 4400: rgb= [255, 217, 182]; break
		case 4500: rgb= [255, 219, 186]; break
		case 4600: rgb= [255, 221, 190]; break
		case 4700: rgb= [255, 223, 194]; break
		case 4800: rgb= [255, 225, 198]; break
		case 4900: rgb= [255, 227, 202]; break
		case 5000: rgb= [255, 228, 206]; break
		case 5100: rgb= [255, 230, 210]; break
		case 5200: rgb= [255, 232, 213]; break
		case 5300: rgb= [255, 233, 217]; break
		case 5400: rgb= [255, 235, 220]; break
		case 5500: rgb= [255, 236, 224]; break
		case 5600: rgb= [255, 238, 227]; break
		case 5700: rgb= [255, 239, 230]; break
		case 5800: rgb= [255, 240, 233]; break
		case 5900: rgb= [255, 242, 236]; break
		case 6000: rgb= [255, 243, 239]; break
		case 6100: rgb= [255, 244, 242]; break
		case 6200: rgb= [255, 245, 245]; break
		case 6300: rgb= [255, 246, 247]; break
		case 6400: rgb= [255, 248, 251]; break
		case 6500: rgb= [255, 249, 253]; break
		case 6600: rgb= [254, 249, 255]; break
		case 6700: rgb= [252, 247, 255]; break
		case 6800: rgb= [249, 246, 255]; break
		case 6900: rgb= [247, 245, 255]; break
		case 7000: rgb= [245, 243, 255]; break
		case 7100: rgb= [243, 242, 255]; break
		case 7200: rgb= [240, 241, 255]; break
		case 7300: rgb= [239, 240, 255]; break
		case 7400: rgb= [237, 239, 255]; break
		case 7500: rgb= [235, 238, 255]; break
		case 7600: rgb= [233, 237, 255]; break
		case 7700: rgb= [231, 236, 255]; break
		case 7800: rgb= [230, 235, 255]; break
		case 7900: rgb= [228, 234, 255]; break
		case 8000: rgb= [227, 233, 255]; break
		case 8100: rgb= [225, 232, 255]; break
		case 8200: rgb= [224, 231, 255]; break
		case 8300: rgb= [222, 230, 255]; break
		case 8400: rgb= [221, 230, 255]; break
		case 8500: rgb= [220, 229, 255]; break
		case 8600: rgb= [218, 229, 255]; break
		case 8700: rgb= [217, 227, 255]; break
		case 8800: rgb= [216, 227, 255]; break
		case 8900: rgb= [215, 226, 255]; break
		case 9000: rgb= [214, 225, 255]; break
		case 9100: rgb= [212, 225, 255]; break
		case 9200: rgb= [211, 224, 255]; break
		case 9300: rgb= [210, 223, 255]; break
		case 9400: rgb= [209, 223, 255]; break
		case 9500: rgb= [208, 222, 255]; break
		case 9600: rgb= [207, 221, 255]; break
		case 9700: rgb= [207, 221, 255]; break
		case 9800: rgb= [206, 220, 255]; break
		case 9900: rgb= [205, 220, 255]; break
		case 10000: rgb= [207, 218, 255]; break
		case 10100: rgb= [207, 218, 255]; break
		case 10200: rgb= [206, 217, 255]; break
		case 10300: rgb= [205, 217, 255]; break
		case 10400: rgb= [204, 216, 255]; break
		case 10500: rgb= [204, 216, 255]; break
		case 10600: rgb= [203, 215, 255]; break
		case 10700: rgb= [202, 215, 255]; break
		case 10800: rgb= [202, 214, 255]; break
		case 10900: rgb= [201, 214, 255]; break
		case 11000: rgb= [200, 213, 255]; break
		case 11100: rgb= [200, 213, 255]; break
		case 11200: rgb= [199, 212, 255]; break
		case 11300: rgb= [198, 212, 255]; break
		case 11400: rgb= [198, 212, 255]; break
		case 11500: rgb= [197, 211, 255]; break
		case 11600: rgb= [197, 211, 255]; break
		case 11700: rgb= [197, 210, 255]; break
		case 11800: rgb= [196, 210, 255]; break
		case 11900: rgb= [195, 210, 255]; break
		case 12000: rgb= [195, 209, 255]; break
		default:
			logWarn("setRgbData: Unknown.")
			colorName = "Unknown"
	}
	def hsvData = hubitat.helper.ColorUtils.rgbToHSV([rgb[0].toInteger(), rgb[1].toInteger(), rgb[2].toInteger()])
	def hue = (0.5 + hsvData[0]).toInteger()
	def saturation = (0.5 + hsvData[1]).toInteger()
	def level = (0.5 + hsvData[2]).toInteger()
	def hslData = [
		hue: hue,
		saturation: saturation,
		level: level
		]
	return hslData
}

def setHue(hue) {
	logDebug("setHue:  hue = ${hue}")
	setColor([hue: hue])
}

def setSaturation(saturation) {
	logDebug("setSaturation: saturation = ${saturation}")
	setColor([saturation: saturation])
}

def setColor(Map color) {
	logDebug("setColor:  ${color} // ${transition_Time}")
	if (transTime == null) { transTime = 0 }
	def transTime = 1000 * transition_Time.toInteger()
	if (color == null) {
		LogWarn("setColor: Color map is null. Command not executed.")
		return
	}
	def level = device.currentValue("level")
	if (color.level) { level = color.level }
	def hue = device.currentValue("hue")
	if (color.hue || color.hue == 0) { hue = color.hue.toInteger() }
	def saturation = device.currentValue("saturation")
	if (color.saturation || color.saturation == 0) { saturation = color.saturation }
	hue = Math.round(0.49 + hue * 3.6).toInteger()
	if (hue < 0 || hue > 360 || saturation < 0 || saturation > 100 || level < 0 || level > 100) {
		logWarn("setColor: Entered hue, saturation, or level out of range! (H:${hue}, S:${saturation}, L:${level}")
        return
    }
	state.currentCT = 0
	sendCmd("""{"smartlife.iot.lightStrip":{"set_light_state":{"ignore_default":1,"on_off":1,"brightness":${level},""" +
			""""color_temp":0,"hue":${hue},"saturation":${saturation},"transition_period":${transTime}}},""" +
			""""smartlife.iot.common.emeter":{"get_realtime":{}}}""")
}

def setRGB(rgb) {
	logDebug("setRGB: ${rgb}") 
logInfo("setRGB: ${rgb}") 
	def rgbArray = rgb.split('\\,')
	def hsvData = hubitat.helper.ColorUtils.rgbToHSV([rgbArray[0].toInteger(), rgbArray[1].toInteger(), rgbArray[2].toInteger()])
	def hue = (0.5 + hsvData[0]).toInteger()
	def saturation = (0.5 + hsvData[1]).toInteger()
	def level = (0.5 + hsvData[2]).toInteger()
	def Map hslData = [
		hue: hue,
		saturation: saturation,
		level: level
		]
	setColor(hslData)
}

def refresh() {
	logDebug("refresh")
	poll()
}

def poll() {
	sendCmd("""{"system":{"get_sysinfo":{}},""" +
			""""smartlife.iot.common.emeter":{"get_realtime":{}}}""")
}

def sendEffect(effData) {
	effData = new groovy.json.JsonBuilder(effData).toString()
	sendCmd("""{"smartlife.iot.lighting_effect":{"set_lighting_effect":""" +
			"""${effData}},"context":{"source":"<id>"},""" +
			""""smartlife.iot.common.emeter":{"get_realtime":{}}}""")
}

def effectCreate() {
	state.createEffect = true
	sendCmd("""{"smartlife.iot.lighting_effect":{"get_lighting_effect":{}}}""")
}

def parseEffect(resp) {
	logDebug("parseEffect: ${resp}")
	if (resp.get_lighting_effect) {
		def effData = resp.get_lighting_effect
		def effName = effData.name
		if (state.createEffect == true) {
			def existngEffect = state.effectPresets.find { it.name == effName }
			if (existngEffect == null) {
				state.effectPresets << effData
				resetLightEffects()
				logDebug("parseEffece: ${effName} added to effectPresets")
			} else {
				logWarn("parseEffect: ${effName} already exists.")
			}
			state.remove("createEffect")
		}
		refresh()
	} else {
		if (resp.set_lighting_effect.err_code != 0) {
			logWarn("parseEffect: Error setting effect.")
		}
		sendCmd("""{"smartlife.iot.lighting_effect":{"get_lighting_effect":{}}}""")
	}
}

def bulbPresetSet(psName, transTime = transition_Time) {
	psName = psName.trim()
	if (transTime == null) { transTime = 0 }
	transTime = 1000 * transTime.toInteger()
	if (state.bulbPresets."${psName}") {
		def psData = state.bulbPresets."${psName}"
		logDebug("bulbPresetSet: ${psData}, transTime = ${transTime}")
		def hue = psData.hue
		hue = Math.round(0.49 + hue * 3.6).toInteger()
		sendCmd("""{"smartlife.iot.lightStrip":{"set_light_state":{"ignore_default":1,"on_off":1,"brightness":${psData.level},""" +
				""""hue":${hue},"color_temp":0,"saturation":${psData.saturation},"transition_period":${transTime}}},""" +
				""""smartlife.iot.common.emeter":{"get_realtime":{}}}""")
	} else {
		logWarn("bulbPresetSet: ${psName} is not a valid name.")
	}
}

def distResp(response) {
	if (response["smartlife.iot.lightStrip"]) {
		sendCmd("""{"system":{"get_sysinfo":{}}}""")
	} else if (response.system) {
		if (response.system.get_sysinfo) {
			if (nameSync == "device") {
				device.setLabel(response.system.get_sysinfo.alias)
				device.updateSetting("nameSync",[type:"enum", value:"none"])
			}
			updateBulbData(response.system.get_sysinfo)
			if(emFunction) { getPower() }
		} else if (response.system.reboot) {
			logWarn("distResp: Rebooting device.")
		} else if (response.system.set_dev_alias) {
			if (response.system.set_dev_alias.err_code != 0) {
				logWarn("distResp: Name Sync from Hubitat to Device returned an error.")
			} else {
				device.updateSetting("nameSync",[type:"enum", value:"none"])
			}
		} else {
			logWarn("distResp: Unhandled response = ${response}")
		}
	} else if (response["smartlife.iot.lighting_effect"]) {
		parseEffect(response["smartlife.iot.lighting_effect"])
	} else if (emFunction && response["smartlife.iot.common.emeter"]) {
		def month = new Date().format("M").toInteger()
		def emeterResp = response["smartlife.iot.common.emeter"]
		if (emeterResp.get_realtime) {
			setPower(emeterResp.get_realtime)
		} else if (emeterResp.get_monthstat.month_list.find { it.month == month }) {
			setEnergyToday(emeterResp.get_monthstat)
		} else if (emeterResp.get_monthstat.month_list.find { it.month == month - 1 }) {
			setLastMonth(emeterResp.get_monthstat)
		} else {
			logWarn("distResp: Unhandled response = ${response}")
		}
	} else if (response["smartlife.iot.common.cloud"]) {
		setBindUnbind(response["smartlife.iot.common.cloud"])
	} else if (response["smartlife.iot.common.system"]) {
		logWarn("distResp: Rebooting device")
	} else {
		logWarn("distResp: Unhandled response = ${response}")
	}
	resetCommsError()
}

def updateBulbData(status) {
	logDebug("updateBulbData: ${status}")
	if (nameSync != "none") {
		device.setLabel(status.alias)
		device.updateSetting("nameSync",[type:"enum", value:"none"])
	}
	def effect = status.lighting_effect_state
	status = status.light_state
	def deviceStatus = [:]
	def onOff = "on"
	if (status.on_off == 0) { onOff = "off" }
	deviceStatus << ["power" : onOff]
	def isChange = false
	if (device.currentValue("switch") != onOff) {
		sendEvent(name: "switch", value: onOff, type: "digital")
		isChange = true
	}
	if (onOff == "on") {
		def colorMode = "RGB"
		if (effect.enable == 1) { colorMode = "EFFECTS" }
		else if (state.currentCT > 0) { colorMode = "CT" }
		def hue = status.hue
		def hubHue = (hue / 3.6).toInteger()
		def saturation = status.saturation
		def level = status.brightness
		if (status.groups) {
			hue = status.groups[0][2]
			saturation = status.groups[0][3]
			level = status.groups[0][4]
		}
		def colorTemp = state.currentCT
		def color = " "
		def colorName = " "
		def effectName = " "
		if (colorMode == "EFFECTS") {
			effectName = effect.name
			level = effect.brightness
			hubHue = 0
			saturation = 0
			colorTemp = 0
		} else if (colorMode == "CT") {
			colorName = getCtName(colorTemp)
			hubHue = 0
			saturation = 0
		} else if (colorMode == "RGB") {
			colorName = getColorName(hue)
			color = "{hue: ${hubHue},saturation:${saturation},level: ${level}}"
		}
		if (level != device.currentValue("level")) {
			deviceStatus << ["level" : level]
			sendEvent(name: "level", value: level, unit: "%")
			isChange = true
		}
		if (effectName != device.currentValue("effectName")) {
			deviceStatus << ["effectName" : effectName]
			sendEvent(name: "effectName", value: effectName)
			isChange = true
		}
		if (device.currentValue("colorTemperature") != colorTemp) {
			isChange = true
			deviceStatus << ["colorTemp" : colorTemp]
			sendEvent(name: "colorTemperature", value: colorTemp)
		}
		if (color != device.currentValue("color")) {
			isChange = true
			deviceStatus << ["color" : color]
			sendEvent(name: "hue", value: hubHue)
			sendEvent(name: "saturation", value: saturation)
			sendEvent(name: "color", value: color)
		}
		if (device.currentValue("colorName") != colorName) {
			deviceStatus << ["colorName" : colorName]
			deviceStatus << ["colorMode" : colorMode]
			sendEvent(name: "colorMode", value: colorMode)
		    sendEvent(name: "colorName", value: colorName)
		}
	}
	if (isChange == true) {
		logInfo("updateBulbData: Status = ${deviceStatus}")
	}
}

//	========================================================
//	===== Communications ===================================
#include davegut.kasaCommunications
//	========================================================
//	===== Energy Monitor ===================================
#include davegut.kasaEnergyMonitor
//	========================================================
//	===== Preferences and Update ===========================
#include davegut.kasaPreferences
//	========================================================
//	===== Bulb and Light Strip Tools =======================
#include davegut.bulbTools

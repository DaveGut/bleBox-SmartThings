library (
	name: "kasaEnergyMonitor",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Kasa energy monitor routines",
	category: "energyMonitor",
	documentationLink: ""
)

def setupEmFunction() {
	if (emFunction) {
		sendEvent(name: "power", value: 0)
		sendEvent(name: "energy", value: 0)
		sendEvent(name: "currMonthTotal", value: 0)
		sendEvent(name: "currMonthAvg", value: 0)
		sendEvent(name: "lastMonthTotal", value: 0)
		sendEvent(name: "lastMonthAvg", value: 0)
		def start = Math.round(30 * Math.random()).toInteger()
		schedule("${start} */30 * * * ?", getEnergyToday)
		runIn(1, getEnergyToday)
		return "Initialized"
	} else if (device.currentValue("power") != null) {
		sendEvent(name: "power", value: 0)
		sendEvent(name: "energy", value: 0)
		sendEvent(name: "currMonthTotal", value: 0)
		sendEvent(name: "currMonthAvg", value: 0)
		sendEvent(name: "lastMonthTotal", value: 0)
		sendEvent(name: "lastMonthAvg", value: 0)
		if (type().contains("Multi")) {
			state.remove("powerPollInterval")
		}
		return "Disabled"
	} else {
		return "Disabled"
	}
}

def getPower() {
	logDebug("getPower")
	if (type().contains("Multi")) {
		sendCmd("""{"context":{"child_ids":["${getDataValue("plugId")}"]},""" +
				""""emeter":{"get_realtime":{}}}""")
	} else if (type().contains("Bulb") || type().contains("Light")) {
		sendCmd("""{"smartlife.iot.common.emeter":{"get_realtime":{}}}""")
	} else {
		sendCmd("""{"emeter":{"get_realtime":{}}}""")
	}
}

def setPower(response) {
	def power = response.power
	if (power == null) { power = response.power_mw / 1000 }
	power = Math.round(10*(power))/10
	def curPwr = device.currentValue("power")
	if (curPwr < 5 && (power > curPwr + 0.3 || power < curPwr - 0.3)) {
		sendEvent(name: "power", value: power, descriptionText: "Watts", unit: "W", type: "digital")
		logDebug("polResp: power = ${power}")
	} else if (power > curPwr + 5 || power < curPwr - 5) {
		sendEvent(name: "power", value: power, descriptionText: "Watts", unit: "W", type: "digital")
		logDebug("polResp: power = ${power}")
	}
}

def getEnergyToday() {
	logDebug("getEnergyToday")
	def year = new Date().format("yyyy").toInteger()
	if (type().contains("Multi")) {
		sendCmd("""{"context":{"child_ids":["${getDataValue("plugId")}"]},""" +
				""""emeter":{"get_monthstat":{"year": ${year}}}}""")
	} else if (type().contains("Bulb") || type().contains("Light")) {
		sendCmd("""{"smartlife.iot.common.emeter":{"get_monthstat":{"year": ${year}}}}""")
	} else {
		sendCmd("""{"emeter":{"get_monthstat":{"year": ${year}}}}""")
	}
}

def setEnergyToday(response) {
	logDebug("setEnergyToday: response = ${response}")
	def month = new Date().format("M").toInteger()
	def data = response.month_list.find { it.month == month }
	def energy = data.energy
	if (energy == null) { energy = data.energy_wh/1000 }
	energy -= device.currentValue("currMonthTotal")
	energy = Math.round(100*energy)/100
	def currEnergy = device.currentValue("energy")
	if (currEnergy < energy + 0.05) {
		sendEvent(name: "energy", value: energy, descriptionText: "KiloWatt Hours", unit: "KWH")
		logDebug("setEngrToday: [energy: ${energy}]")
	}
	setThisMonth(response)
}

def setThisMonth(response) {
	logDebug("setThisMonth: response = ${response}")
	def month = new Date().format("M").toInteger()
	def day = new Date().format("d").toInteger()
	def data = response.month_list.find { it.month == month }
	def totEnergy = data.energy
	if (totEnergy == null) { 
		totEnergy = data.energy_wh/1000
	}
	totEnergy = Math.round(100*totEnergy)/100
	def avgEnergy = 0
	if (day != 1) { 
		avgEnergy = totEnergy /(day - 1) 
	}
	avgEnergy = Math.round(100*avgEnergy)/100

	sendEvent(name: "currMonthTotal", value: totEnergy, 
			  descriptionText: "KiloWatt Hours", unit: "kWh")
	sendEvent(name: "currMonthAvg", value: avgEnergy, 
			  descriptionText: "KiloWatt Hours per Day", unit: "kWh/D")
	logDebug("setThisMonth: Energy stats set to ${totEnergy} // ${avgEnergy}")
	if (month != 1) {
		setLastMonth(response)
	} else {
		def year = new Date().format("yyyy").toInteger()
		if (type().contains("Multi")) {
			sendCmd("""{"context":{"child_ids":["${getDataValue("plugId")}"]},""" +
					""""emeter":{"get_monthstat":{"year": ${year}}}}""")
		} else if (type().contains("Bulb") || type().contains("Light")) {
			sendCmd("""{"smartlife.iot.common.emeter":{"get_monthstat":{"year": ${year}}}}""")
		} else {
			sendCmd("""{"emeter":{"get_monthstat":{"year": ${year}}}}""")
		}
	}
}

def setLastMonth(response) {
	logDebug("setLastMonth: response = ${response}")
	def year = new Date().format("yyyy").toInteger()
	def month = new Date().format("M").toInteger()
	def day = new Date().format("d").toInteger()
	def lastMonth
	if (month == 1) {
		lastMonth = 12
	} else {
		lastMonth = month - 1
	}
	def monthLength
	switch(lastMonth) {
		case 4:
		case 6:
		case 9:
		case 11:
			monthLength = 30
			break
		case 2:
			monthLength = 28
			if (year == 2020 || year == 2024 || year == 2028) { monthLength = 29 }
			break
		default:
			monthLength = 31
	}
	def data = response.month_list.find { it.month == lastMonth }
	def totEnergy
	if (data == null) {
		totEnergy = 0
	} else {
		totEnergy = data.energy
		if (totEnergy == null) { 
			totEnergy = data.energy_wh/1000
		}
		totEnergy = Math.round(100*totEnergy)/100
	}
	def avgEnergy = 0
	if (day !=1) {
		avgEnergy = totEnergy /(day - 1)
	}
	avgEnergy = Math.round(100*avgEnergy)/100
	sendEvent(name: "lastMonthTotal", value: totEnergy, 
			  descriptionText: "KiloWatt Hours", unit: "kWh")
	sendEvent(name: "lastMonthAvg", value: avgEnergy, 
			  descriptionText: "KiloWatt Hoursper Day", unit: "kWh/D")
	logDebug("setLastMonth: Energy stats set to ${totEnergy} // ${avgEnergy}")
}

library (
	name: "kasaPreferences",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Kasa updated and preferences routines",
	category: "energyMonitor",
	documentationLink: ""
)

//	===== Preference Methods =====
def setPollInterval(interval = state.pollInterval) {
	if (interval == "default" || interval == "off") {
		interval = "30 minutes"
	} else if (useCloud && interval.contains("sec")) {
		interval = "1 minute"
	}
	state.pollInterval = interval
	def pollInterval = interval.substring(0,2).toInteger()
	if (interval.contains("sec")) {
		def start = Math.round((pollInterval-1) * Math.random()).toInteger()
		schedule("${start}/${pollInterval} * * * * ?", "poll")
		state.pollWarning = "Polling intervals of less than one minute can take high " +
			"resources and may impact hub performance."
	} else {
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${pollInterval} * * * ?", "poll")
		state.remove("pollWarning")
	}
	logDebug("setPollInterval: interval = ${interval}.")
	return interval
}

def rebootDevice() {
	logWarn("rebootDevice: User Commanded Reboot Device!")
	device.updateSetting("rebootDev", [type:"bool", value: false])
	if (type().contains("Bulb") || type().contains("Light")) {
		sendCmd("""{"smartlife.iot.common.system":{"reboot":{"delay":1}}}""")
	} else {
		sendCmd("""{"system":{"reboot":{"delay":1}}}""")
	}
	pauseExecution(10000)
	return "REBOOTING DEVICE"
}

def bindUnbind() {
	def meth = "cnCloud"
	if (type().contains("Bulb") || type().contains("Light")) {
		meth = "smartlife.iot.common.cloud"
	}
	def message
	if (bind == null) {
		sendLanCmd("""{"${meth}":{"get_info":{}}}""")
		message = "Updating to current device value"
	} else if (bind) {
		if (!parent.useKasaCloud || parent.userName == null || parent.userPassword == null) {
			message = "useKasaCtr, userName or userPassword not set"
			sendLanCmd("""{"${meth}":{"get_info":{}}}""")
		} else {
			message = "Sending bind command"
			sendLanCmd("""{"${meth}":{"bind":{"username":"${parent.userName}",""" +
					""""password":"${parent.userPassword}"}},""" +
					""""${meth}":{"get_info":{}}}""")
		}
	} else if (!bind) {
		if (!getDataValue("deviceIP")) {
			message = "Not set. No deviceIP"
			setCommsType(true)
		} else if (type() == "Light Strip") {
			message = "Not set. Light Strip"
			setCommsType(true)
		} else {
			message = "Sending unbind command"
			sendLanCmd("""{"${meth}":{"unbind":""},"${meth}":{"get_info":{}}}""")
		}
	}
	pauseExecution(5000)
	return message
}

def setBindUnbind(cmdResp) {
	def bindState = true
	if (cmdResp.get_info) {
		if (cmdResp.get_info.binded == 0) { bindState = false }
		logInfo("setBindUnbind: Bind status set to ${bindState}")
		setCommsType(bindState)
	} else if (cmdResp.bind.err_code == 0){
		def meth = "cnCloud"
		if (type().contains("Bulb") || type().contains("Light")) {
			meth = "smartlife.iot.common.cloud"
		}
		if (!device.contains("Multi") || getDataValue("plugNo") == "00") {
			sendLanCmd("""{"${meth}":{"get_info":{}}}""")
		} else {
			logWarn("setBindUnbind: Multiplug Plug 00 not installed.")
		}
	} else {
		logWarn("setBindUnbind: Unhandled response: ${cmdResp}")
	}
}
/////////////////////////////////////////////
def setCommsType(bindState) {
	def commsType = "LAN"
	def cloudCtrl = false
	state.lastCommand = """{"system":{"get_sysinfo":{}}}"""
	if (bindState == true && useCloud == true && parent.useKasaCloud && 
		parent.userName && parent.userPassword) {
		state.remove("lastLanCmd")
		commsType = "CLOUD"
		cloudCtrl = true
	} else if (altLan == true) {
		commsType = "AltLAN"
	}
	def commsSettings = [bind: bindState, useCloud: cloudCtrl, commsType: commsType]
	device.updateSetting("bind", [type:"bool", value: bindState])
	device.updateSetting("useCloud", [type:"bool", value: cloudCtrl])
	sendEvent(name: "connection", value: "${commsType}")
	log.info "[${type()}, ${driverVer()}, ${device.label}]  setCommsType: ${commsSettings}"
	if (type().contains("Multi")) {
		def coordData = [:]
		coordData << [bind: bindState]
		coordData << [useCloud: cloudCtrl]
		coordData << [connection: commsType]
		parent.coordinate("commsData", coordData, getDataValue("deviceId"), getDataValue("plugNo"))
	}
	pauseExecution(1000)
}
		
def ledOn() {
	logDebug("ledOn: Setting LED to on")
	sendCmd("""{"system":{"set_led_off":{"off":0},""" +
			""""get_sysinfo":{}}}""")
}

def ledOff() {
	logDebug("ledOff: Setting LED to off")
	sendCmd("""{"system":{"set_led_off":{"off":1},""" +
			""""get_sysinfo":{}}}""")
}

def syncName() {
	def message
	if (nameSync == "Hubitat") {
		message = "Syncing device's name from the Hubitat Label/"
		if (type().contains("Multi")) {
			sendCmd("""{"context":{"child_ids":["${getDataValue("plugId")}"]},""" +
					""""system":{"set_dev_alias":{"alias":"${device.label}"}}}""")
		} else {
			sendCmd("""{"system":{"set_dev_alias":{"alias":"${device.label}"}}}""")
		}
	} else if (nameSync == "device") {
		message = "Syncing Hubitat's Label from the device's alias."
		poll()
	}
	return message
}
